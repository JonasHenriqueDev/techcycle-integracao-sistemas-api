package br.upe.is;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NotificacaoTechCycleApplicationTests {

	@Test
	void contextLoads() {
	}

}
