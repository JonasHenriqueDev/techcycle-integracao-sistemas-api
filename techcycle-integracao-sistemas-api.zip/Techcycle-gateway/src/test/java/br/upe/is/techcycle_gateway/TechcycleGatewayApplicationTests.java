package br.upe.is.techcycle_gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TechcycleGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
